'use client';
import {useEffect, useRef, type ReactNode} from 'react';
import {clamp, reducedMotion, subscribeScroll} from '@/lib/motion';
export function CinematicHero({children}: {children: ReactNode}) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const node = ref.current; if (!node) return;
    const preference = matchMedia('(prefers-reduced-motion: reduce)');
    const fine = matchMedia('(hover: hover) and (pointer: fine)');
    let frame = 0, targetX = 0, targetY = 0, x = 0, y = 0;
    const draw = () => { frame = 0; x += (targetX - x) * .16; y += (targetY - y) * .16; node.style.setProperty('--pointer-x', `${x.toFixed(2)}px`); node.style.setProperty('--pointer-y', `${y.toFixed(2)}px`); if (Math.abs(targetX-x)+Math.abs(targetY-y) > .08) frame = requestAnimationFrame(draw); };
    const pointer = (event: PointerEvent) => { if (preference.matches || !fine.matches || event.pointerType !== 'mouse') return; const r = node.getBoundingClientRect(); targetX = clamp((event.clientX-r.left)/r.width,0,1)*12-6; targetY = clamp((event.clientY-r.top)/r.height,0,1)*12-6; if (!frame) frame = requestAnimationFrame(draw); };
    const reset = () => { targetX = targetY = 0; if (!frame) frame = requestAnimationFrame(draw); };
    const clear = () => { cancelAnimationFrame(frame); frame = 0; x = y = targetX = targetY = 0; node.style.setProperty('--pointer-x','0px'); node.style.setProperty('--pointer-y','0px'); node.style.setProperty('--hero-exit','0'); };
    preference.addEventListener('change', clear); fine.addEventListener('change', reset);
    node.addEventListener('pointermove', pointer, {passive:true}); node.addEventListener('pointerleave', reset);
    const unsubscribe = subscribeScroll(() => { if (reducedMotion()) return; const r = node.getBoundingClientRect(); if (r.bottom < 0) return; node.style.setProperty('--hero-exit', String(clamp(-r.top / Math.max(r.height,1)))); });
    return () => { unsubscribe(); cancelAnimationFrame(frame); preference.removeEventListener('change', clear); fine.removeEventListener('change', reset); node.removeEventListener('pointermove', pointer); node.removeEventListener('pointerleave', reset); };
  }, []);
  return <section ref={ref} className="v4-hero v5-hero"><div className="v5-depth-grid" aria-hidden="true"/><div className="v5-precision-axis" aria-hidden="true"><span>01 / BIOSMART</span></div>{children}</section>;
}
