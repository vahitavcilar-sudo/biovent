'use client';
import {useEffect,useRef} from 'react';
import {usePathname,useRouter} from 'next/navigation';
import {basePath} from '@/lib/paths';
import {motion,reducedMotion} from '@/lib/motion';
export function PageTransition(){
 const pathname=usePathname();const router=useRouter();const layer=useRef<HTMLDivElement>(null);const pending=useRef(false);const destination=useRef<string|null>(null);const timer=useRef<ReturnType<typeof setTimeout>|null>(null);const watchdog=useRef<ReturnType<typeof setTimeout>|null>(null);const animation=useRef<Animation|null>(null);
 const clear=()=>{if(timer.current)clearTimeout(timer.current);if(watchdog.current)clearTimeout(watchdog.current);animation.current?.cancel();animation.current=null;pending.current=false;delete document.documentElement.dataset.routeState;if(layer.current)layer.current.style.visibility='hidden';};
 useEffect(()=>{
  const navigate=(href:string)=>{
   const target=new URL(href,location.href);if(target.origin!==location.origin)return;
   const local=basePath&&target.pathname.startsWith(basePath+'/')?target.pathname.slice(basePath.length):target.pathname;
   const route=local+target.search+target.hash;
   if(target.pathname===location.pathname&&target.search===location.search){clear();router.push(route);return;}
   clear();if(reducedMotion()){router.push(route);return;}
   destination.current=route;pending.current=true;document.documentElement.dataset.routeState='leaving';const el=layer.current;
   if(el){el.style.visibility='visible';const rtl=document.documentElement.dir==='rtl';animation.current=el.animate([{clipPath:rtl?'inset(0 0 0 100%)':'inset(0 100% 0 0)'},{clipPath:'inset(0)'}],{duration:motion.routeCover,easing:motion.standard,fill:'forwards'});}
   timer.current=setTimeout(()=>router.push(route),motion.routeCover-30);watchdog.current=setTimeout(clear,motion.routeTimeout);
  };
  const click=(event:MouseEvent)=>{if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;const link=(event.target as Element)?.closest<HTMLAnchorElement>('a[href]');if(!link||link.hasAttribute('download')||link.target&&link.target!=='_self')return;const target=new URL(link.href,location.href);if(target.origin!==location.origin||!target.pathname.startsWith(basePath+'/')||/\.[a-z0-9]+$/i.test(target.pathname))return;if(target.pathname===location.pathname&&target.search===location.search)return;event.preventDefault();event.stopPropagation();navigate(link.href);};
  const custom=(event:Event)=>navigate((event as CustomEvent<string>).detail);
  const preference=matchMedia('(prefers-reduced-motion: reduce)');const changed=()=>{if(preference.matches){const target=pending.current?destination.current:null;clear();if(target)router.push(target);}};
  document.addEventListener('click',click,true);document.addEventListener('biovent:navigate',custom);preference.addEventListener('change',changed);document.documentElement.dataset.routeMotion='ready';
  return()=>{document.removeEventListener('click',click,true);document.removeEventListener('biovent:navigate',custom);preference.removeEventListener('change',changed);delete document.documentElement.dataset.routeMotion;clear();};
 },[router]);
 useEffect(()=>{if(!pending.current)return;const el=layer.current;if(!el){clear();return;}if(timer.current)clearTimeout(timer.current);if(watchdog.current)clearTimeout(watchdog.current);animation.current?.cancel();delete document.documentElement.dataset.routeState;const rtl=document.documentElement.dir==='rtl';animation.current=el.animate([{clipPath:'inset(0)'},{clipPath:rtl?'inset(0 100% 0 0)':'inset(0 0 0 100%)'}],{duration:motion.routeClear,easing:motion.enter,fill:'forwards'});const current=animation.current;current.finished.then(()=>{if(animation.current===current){clear();document.getElementById('main')?.focus({preventScroll:true});}}).catch(()=>{});watchdog.current=setTimeout(clear,motion.routeTimeout);},[pathname]);
 return <div ref={layer} className="route-transition-layer" aria-hidden="true"><span/></div>;
}
