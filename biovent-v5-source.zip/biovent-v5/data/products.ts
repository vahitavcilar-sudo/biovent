import refs from './references.json';
import smartMaster from './smart-asset.json';
import type { CopyKey } from '@/lib/i18n';
export type ProductId='smart'|'promx'|'monoblock'|'zygoma';
export type Reference=readonly [number,string];
function referenceRows(rows:readonly (string|number)[][]):Reference[]{return rows.map(row=>{if(row.length!==2||typeof row[0]!=='number'||typeof row[1]!=='string')throw new Error('Invalid source reference');return [row[0],row[1]] as const})}
const promxReferences=Object.fromEntries(Object.entries(refs.promx).map(([diameter,rows])=>[diameter,referenceRows(rows)]));
export interface Product {id:ProductId;name:string;catalogueName:string;description:CopyKey;tag:CopyKey;specCopy:CopyKey;image:string;imageWidth:number;imageHeight:number;catalogue:'smart'|'portfolio';page:number;design:'twoPiece'|'onePiece'|'seeCatalog';connection:'conical'|'internalHex'|'seeCatalog';diameters:readonly number[];lengths:readonly number[];references?:Record<string,readonly Reference[]>;features:readonly CopyKey[];}
export const products:readonly Product[]=[
{id:'smart',name:'Smart Implant',catalogueName:'BIOSmart',description:'smartDesc',tag:'smartTag',specCopy:'smartSpecs',image:smartMaster.image||'',imageWidth:smartMaster.width||1320,imageHeight:smartMaster.height||1153,catalogue:'smart',page:3,design:'twoPiece',connection:'conical',diameters:[3.5,4,4.5,5],lengths:[],features:['featureConnection','featureBody','thread','featureComponents']},
{id:'promx',name:'Promx Implant',catalogueName:'VTX Two Piece',description:'promxDesc',tag:'promxTag',specCopy:'promxSpecs',image:'/images/products/promx/implant.webp',imageWidth:547,imageHeight:1070,catalogue:'portfolio',page:4,design:'twoPiece',connection:'internalHex',diameters:[3.3,3.75,4.2,4.7,5.2,6],lengths:[6,8,10,11.5,13,16],references:promxReferences,features:['connection','surface','included']},
{id:'monoblock',name:'Monoblock Implant',catalogueName:'Compressive',description:'monoblockDesc',tag:'monoblockTag',specCopy:'monoblockSpecs',image:'/images/products/monoblock/implant.webp',imageWidth:1280,imageHeight:1280,catalogue:'portfolio',page:5,design:'onePiece',connection:'seeCatalog',diameters:[3.3,3.75,4.2,4.7],lengths:[6,8,10,11.5,13,16],features:['onePiece','sizes']},
{id:'zygoma',name:'Zygoma Implant',catalogueName:'Zygomatic',description:'zygomaDesc',tag:'zygomaTag',specCopy:'zygomaSpecs',image:'/images/products/zygoma/implant.webp',imageWidth:1000,imageHeight:2000,catalogue:'portfolio',page:7,design:'seeCatalog',connection:'seeCatalog',diameters:[4.2],lengths:[35,37.5,40,42.5,45,47.5,50,52.5,55],references:{'4.2':referenceRows(refs.zygoma)},features:['diameter','length']}
];
export function findProduct(id:string){return products.find(p=>p.id===id)}
export const productIds=products.map(p=>p.id);
