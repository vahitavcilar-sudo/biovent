
'use client';
import {useEffect,useRef} from 'react';
import {products} from '@/data/products';
import {ProductVisual} from '@/components/product/product-visual';
import {Label,Lines} from '@/components/ui/primitives';
import {getV4Copy} from '@/lib/v4-copy';
import type {Copy,Locale} from '@/lib/i18n';
import {clamp,subscribeScroll} from '@/lib/motion';
export function SignatureScene({locale,copy:c}:{locale:Locale;copy:Copy}){const ref=useRef<HTMLElement>(null);useEffect(()=>{const media=matchMedia('(prefers-reduced-motion:reduce)');const update=()=>{const e=ref.current;if(!e)return;const r=e.getBoundingClientRect();if(r.bottom<0||r.top>innerHeight)return;e.style.setProperty('--signature-progress',media.matches?'0':String(clamp((innerHeight-r.top)/(innerHeight+r.height))));};const stop=subscribeScroll(update);media.addEventListener('change',update);return()=>{stop();media.removeEventListener('change',update)}},[]);return <section ref={ref} className="v6-signature" aria-label={c.engineering}><div className="v6-signature-inner"><h2><Lines text={getV4Copy(locale).statement}/></h2><div className="v6-signature-grid" aria-hidden="true"/><ProductVisual product={products[0]} large/><div className="v6-signature-caption container"><Label>06 / BIOSmart</Label><span>{c.collection}</span></div></div></section>}
