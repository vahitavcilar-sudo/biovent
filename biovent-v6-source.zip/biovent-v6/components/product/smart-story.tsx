'use client';
import {useEffect,useRef,useState,type CSSProperties} from 'react';
import type {Copy,Locale} from '@/lib/i18n';
import {getV4Copy} from '@/lib/v4-copy';
import {products} from '@/data/products';
import {ProductVisual} from './product-visual';
import {Button,Label,Lines} from '@/components/ui/primitives';
import {reducedMotion,subscribeScroll} from '@/lib/motion';
const anchors=[[640,112],[790,245],[700,550],[890,665],[780,890]];
const poses=[[0,28,0,1],[-16,18,.5,1.04],[12,0,-.4,1],[-18,-22,.7,1.06],[0,-32,0,1.1]];
export function SmartStory({locale,copy:c}:{locale:Locale;copy:Copy}){
 const v=getV4Copy(locale);const [active,setActive]=useState(0);const refs=useRef<(HTMLElement|null)[]>([]);const section=useRef<HTMLElement>(null);
 const steps=[{title:c.featureConnection,copy:c.featureConnectionCopy},{title:v.platform,copy:v.platformCopy},{title:c.featureBody,copy:c.featureBodyCopy},{title:c.thread,copy:c.threadCopy},{title:v.surface,copy:v.surfaceCopy}];
 useEffect(()=>{section.current?.setAttribute('data-story-ready','true');const stop=subscribeScroll(()=>{const box=section.current?.getBoundingClientRect();if(!box||box.bottom<0||box.top>innerHeight)return;const target=innerHeight*.48;let current=0;refs.current.forEach((el,i)=>{if(el&&el.getBoundingClientRect().top<=target)current=i});setActive(old=>old===current?old:current)});return()=>{stop();section.current?.removeAttribute('data-story-ready')};},[]);
 const [x,y]=anchors[active];const pose=poses[active];const sign=locale==='ar'?-1:1;
 return <section ref={section} id="smart-engineering" className="v4-story v5-story v6-story section-pad" style={{'--story-x':`${pose[0]*sign}px`,'--story-y':`${pose[1]}px`,'--story-angle':`${pose[2]*sign}deg`,'--story-scale':pose[3]} as CSSProperties} data-story-active={active}>
  <div className="container"><div className="section-heading"><div><Label>{c.engineering}</Label><h2><Lines text={v.story}/></h2></div><p>{v.storyCopy}</p></div>
   <div className="v4-story-grid"><div className="v4-story-sticky">
    <div className="v4-story-nav" role="group" aria-label={c.smartFocusLabel}>{steps.map((s,i)=><button key={i} aria-pressed={active===i} onClick={()=>{setActive(i);refs.current[i]?.scrollIntoView({block:'center',behavior:reducedMotion()?'instant':'smooth'})}}><span>0{i+1}</span>{s.title}</button>)}</div>
    <div className="v5-story-scene"><ProductVisual product={products[0]} large/><svg className="story-leaders" viewBox="0 0 1320 1153" aria-hidden="true"><g key={active}><path d={`M ${x} ${y} L ${x+(locale==='ar'?-105:105)} ${y-55} L ${locale==='ar'?150:1170} ${y-55}`}/><circle cx={x} cy={y} r="5"/></g></svg></div>
    <div className="v5-story-callout"><span>0{active+1} / 05</span><strong key={active}>{steps[active].title}</strong></div><div className="v5-story-progress" aria-hidden="true"><span style={{transform:`scaleX(${(active+1)/5})`}}/></div>
    <div className="v4-story-marker"><span>BIOSmart</span><span>0{active+1} / 05</span></div>
   </div><div className="v4-story-chapters">{steps.map((s,i)=><article ref={el=>{refs.current[i]=el}} data-index={i}  key={i} className={active===i?'is-active':''}><span className="v4-chapter-index">0{i+1}</span><h3>{s.title}</h3><p>{s.copy}</p>{i===4&&<Button href={`/${locale}/products/smart/`} secondary>{c.technicalInfo}</Button>}</article>)}</div>
   </div>
  </div>
 </section>
}
