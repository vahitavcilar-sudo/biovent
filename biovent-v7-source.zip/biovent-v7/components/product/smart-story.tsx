'use client';
import {MotionToggle} from '@/components/media/motion-toggle';
import {useEffect,useRef,useState,type CSSProperties,type ReactNode} from 'react';
import type {Copy,Locale} from '@/lib/i18n';
import {getV4Copy} from '@/lib/v4-copy';
import {getV7Copy} from '@/lib/v7-copy';
import {smartInspectionSteps} from '@/lib/product-inspection';
import {inspectionFrames,sceneTimelines} from '@/lib/scene-timelines';
import {products} from '@/data/products';
import {mediaAssets} from '@/data/media';
import {Product360} from '@/components/media/product-360';
import {ProductVisual} from './product-visual';
import {StaticImage} from '@/components/ui/static-image';
import {Button,Label,Lines} from '@/components/ui/primitives';
import {reducedMotion,subscribeScroll} from '@/lib/motion';
const anchors=[[640,112],[790,245],[700,550],[890,665],[780,890]];
export function SmartStory({locale,copy:c,hero}:{locale:Locale;copy:Copy;hero?:ReactNode}){
 const v=getV4Copy(locale),t=getV7Copy(locale),steps=smartInspectionSteps(locale,c);const [active,setActive]=useState(0);const [engaged,setEngaged]=useState(!hero);const [focused,setFocused]=useState(true);const [popup,setPopup]=useState(false);const refs=useRef<(HTMLElement|null)[]>([]);const section=useRef<HTMLElement>(null);const hotspot=useRef<HTMLButtonElement>(null);
 useEffect(()=>{section.current?.setAttribute('data-story-ready','true');const stop=subscribeScroll(()=>{const box=section.current?.getBoundingClientRect();if(!box||box.bottom<0||box.top>innerHeight)return;const target=innerHeight*sceneTimelines.inspection.activeViewport;let current=0;refs.current.forEach((el,i)=>{if(el&&el.getBoundingClientRect().top<=target)current=i});setEngaged(!hero||!!refs.current[0]&&refs.current[0].getBoundingClientRect().top<=target);setActive(old=>old===current?old:current)});return()=>{stop();section.current?.removeAttribute('data-story-ready')};},[hero]);
 useEffect(()=>setPopup(false),[active]);useEffect(()=>{if(!popup)return;const key=(e:KeyboardEvent)=>{if(e.key==='Escape'){setPopup(false);hotspot.current?.focus()}};document.addEventListener('keydown',key);return()=>document.removeEventListener('keydown',key)},[popup]);
 const [x,y]=(mediaAssets.smartInspection as import('@/data/media').MediaAsset).hotspotAnchors?.[active]||anchors[active];const pose=inspectionFrames[engaged&&focused?active+1:0];
 return <section ref={section} id="smart-engineering" data-media-scroll-scope className={`v4-story v5-story v6-story v7-story ${hero?'v7-detail-journey':''} section-pad`} style={{'--story-x':`${pose.x}px`,'--story-y':`${pose.y}px`,'--story-angle':'0deg','--story-scale':pose.scale,'--story-origin':pose.origin} as CSSProperties} data-story-active={active}>
  {hero}
  <div className="v7-shared-inspection"><div className="v4-story-sticky">
   <div className="v4-story-nav" role="group" aria-label={c.smartFocusLabel}>{steps.map((s,i)=><button key={i} aria-pressed={active===i} onClick={()=>{setFocused(true);refs.current[i]?.scrollIntoView({block:'center',behavior:reducedMotion()?'instant':'smooth'})}}><span>0{i+1}</span>{s.title}</button>)}</div>
   <div className="v5-story-scene"><Product360 media={mediaAssets.smartInspection} locale={locale}><ProductVisual product={products[0]} priority={!!hero} large mediaKey="smartInspection" locale={locale}/></Product360>{engaged&&<svg data-video-anchors={!!(mediaAssets.smartInspection as import('@/data/media').MediaAsset).hotspotAnchors} className="story-leaders" viewBox="0 0 1320 1153" aria-label={steps[active].title}><path key={active} aria-hidden="true" d={`M ${x} ${y} L ${x+(locale==='ar'?-105:105)} ${y-55} L ${locale==='ar'?150:1170} ${y-55}`}/><circle aria-hidden="true" cx={x} cy={y} r="4"/><foreignObject x={x-60} y={y-60} width="120" height="120"><button ref={hotspot} className="technical-hotspot" aria-label={`${t.technical}: ${steps[active].title}`} aria-expanded={popup} aria-controls="smart-hotspot-detail" onClick={()=>setPopup(!popup)}/></foreignObject></svg>}{popup&&<div className="v7-hotspot-panel" id="smart-hotspot-detail"><button onClick={()=>{setPopup(false);hotspot.current?.focus()}} aria-label={c.close}>×</button><strong>{steps[active].title}</strong><p>{steps[active].copy}</p></div>}</div>
   <div className="v5-story-callout"><span>0{active+1} / 05</span><strong>{steps[active].title}</strong></div><div className="v5-story-progress" aria-hidden="true"><span style={{transform:`scaleX(${(active+1)/5})`}}/></div>
   <div className="inspection-actions"><button aria-pressed={focused} onClick={()=>{if(!engaged){setEngaged(true);setFocused(true)}else setFocused(!focused)}}>{engaged&&focused?t.full:t.focus}</button><button onClick={()=>{setFocused(false);setPopup(false)}}>{t.reset}</button></div><MotionToggle locale={locale}/><div className="v4-story-marker"><span>BIOSmart / {t.still}</span></div>
  </div></div>
  <div className="container v7-engineering-copy"><div className="section-heading"><div><Label>{c.engineering}</Label><h2><Lines text={v.story}/></h2></div><p>{v.storyCopy}</p></div><div className="v4-story-chapters">{steps.map((s,i)=><article ref={el=>{refs.current[i]=el}} data-index={i} id={`smart-chapter-${i}`} key={i} className={active===i?'is-active':''}><span className="v4-chapter-index">0{i+1}</span><h3>{s.title}</h3><p>{s.copy}</p>{i===4&&<><figure className="inspection-surface"><StaticImage src="/images/editorial/surface-detail.png" alt={t.surface} width={168} height={168}/><figcaption>BIOSmart / 03 · {c.source}</figcaption></figure><Button href={`/${locale}/products/smart/`} secondary>{c.technicalInfo}</Button></>}</article>)}</div></div>
 </section>
}
