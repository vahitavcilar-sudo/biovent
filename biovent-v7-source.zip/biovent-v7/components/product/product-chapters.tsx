'use client';
import {useEffect,useState} from 'react';
import {sceneTimelines} from '@/lib/scene-timelines';
import {subscribeScroll} from '@/lib/motion';
import type {Copy,Locale} from '@/lib/i18n';
import {getV7Copy} from '@/lib/v7-copy';
export function ProductChapters({locale,copy:c,smart}:{locale:Locale;copy:Copy;smart:boolean}){const [active,setActive]=useState('product-overview');const tabs=[{id:'product-overview',label:c.overview},...(smart?[{id:'smart-chapter-0',label:c.engineering}]:[]),{id:'product-technical',label:c.technicalInfo},{id:'product-documents',label:c.documents}];useEffect(()=>subscribeScroll(()=>{let current='product-overview';for(const t of tabs){const e=document.getElementById(t.id);if(e&&e.getClientRects().length&&e.getBoundingClientRect().top<innerHeight*sceneTimelines.navigation.activeViewport)current=t.id}setActive(old=>old===current?old:current)}),[smart]);return <nav className="product-chapter-nav" aria-label={getV7Copy(locale).navigate}>{tabs.map(t=><a key={t.id} href={`#${t.id}`} aria-current={active===t.id?'location':undefined} onClick={()=>{if(t.id==='product-documents')document.dispatchEvent(new CustomEvent('biovent:product-tab',{detail:2}));else if(t.id==='product-technical')document.dispatchEvent(new CustomEvent('biovent:product-tab',{detail:1}));}}>{t.label}</a>)}</nav>}
