@echo off
cd /d "%~dp0"
"%~dp0BIOVENT-ONIZLEME.exe"
pause
